from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class TrackingInputRequest(BaseModel):
    query: str = Field(
        ...,
        description="Tracking identifier, e.g. '16015246221', '160-15246221', or 'MSKU1234567'",
        examples=["16015246221", "160-15246221", "MAEU1234567"],
    )
    mode: Optional[str] = Field(
        default=None,
        description="Optional explicit transport mode ('AIR' or 'SEA'). If omitted, agent automatically detects.",
    )
    carrier_code: Optional[str] = Field(
        default=None,
        description="Optional carrier code or airline prefix override (e.g. '160' or 'CX')",
    )
    force_refresh: bool = Field(
        default=False,
        description="Force bypass of cached token or tracking snapshot",
    )


class CarrierInfo(BaseModel):
    code: str
    prefix: Optional[str] = None
    name: str
    mode: str
    primary_provider: str
    fallback_providers: List[str] = []


class UnifiedTrackingEvent(BaseModel):
    station: Optional[str] = None
    status_code: Optional[str] = None
    status_message: str
    event_time: Optional[datetime] = None
    flight_info: Optional[str] = None
    pieces: Optional[int] = None
    weight: Optional[float] = None
    raw_status: Optional[str] = None


class ProviderAttempt(BaseModel):
    provider_name: str
    status: str  # 'SUCCESS', 'FAILED', 'FALLBACK_TRIGGERED'
    http_status: Optional[int] = None
    latency_ms: float
    error: Optional[str] = None


class AgentDecisionTrail(BaseModel):
    detected_mode: str
    carrier_identified: str
    carrier_code: str
    provider_plan: List[str]
    attempts: List[ProviderAttempt] = []
    final_provider_used: Optional[str] = None


class UnifiedTrackingResponse(BaseModel):
    tracking_number: str
    mode: str  # 'AIR' or 'SEA'
    carrier: CarrierInfo
    status: str
    message: Optional[str] = None
    origin: Optional[str] = None
    destination: Optional[str] = None
    pieces: Optional[int] = None
    weight: Optional[Dict[str, Any]] = None
    volume: Optional[float] = None
    latest_event: Optional[UnifiedTrackingEvent] = None
    events: List[UnifiedTrackingEvent] = []
    agent_trail: AgentDecisionTrail
    raw_data: Optional[Dict[str, Any]] = None
